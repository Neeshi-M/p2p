#include <iostream>
#include <bits/stdc++.h>
#include <vector>
#include <string>
#include <filesystem>
#include <sstream>
#include <fstream>
#include <unistd.h>
#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <string.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/wait.h>

using namespace std;
// #define PORT 8080


using std::cout; using std::cin;
using std::endl; using std::string;
using std::filesystem::directory_iterator;


string* sort_name (string* arr, int len){
    string temp;
    for (int i = 0; i < len; ++i) {
        for (int j = 0; j < len - i; ++j) {
            if (arr[j] > arr[j + 1]) {
                temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
    return arr;
}

string convertToString(char* a, int size)
{
    int i;
    string s = "";
    for (i = 0; i < size; i++) {
        s = s + a[i];
    }
    return s;
}

void *get_in_addr(struct sockaddr *sa)
{
    if (sa->sa_family == AF_INET) {
        return &(((struct sockaddr_in*)sa)->sin_addr);
    }

    return &(((struct sockaddr_in6*)sa)->sin6_addr);
}

int main(int argc, char *argv[]) {
    
    string path = argv[2];
    string my_files[1000];
    int x=0;
    for (const auto & file : directory_iterator(path)){
        std::filesystem::path downloaded = path + "/Downloaded";
        if(file.path()==downloaded){
            continue;
        }
        std::stringstream path_string{file.path().u8string()};
        std::string segment;
        
        string seglist[1000];

        int len =0;
        while(std::getline(path_string, segment, '/')){
            seglist[len]=(segment);
            len++;
        }
        my_files[x] = seglist[len-1];
        x++;

    }
    string config_text_file = argv[1];
    std::string myText;
    std::ifstream MyReadFile(config_text_file);
    int i=0;
    
    int client_id, client_port, unique_private_id;
    int num_neighbours;
    int neighbour_id[1000]; 
    int neighbour_port[1000];
    int num_files;
    string file_names[1000];

    while (std::getline(MyReadFile, myText)) {
        
        std::stringstream mytext;
        mytext.str(myText);
        std::string seg;

        
        string list[1000];
        int q=0;
        while(std::getline(mytext, seg, ' ')){
            list[q]=seg;
            q++;
        }

        if(i==0){
            client_id = stoi(list[0]);
            client_port = stoi(list[1]);
            unique_private_id = stoi(list[2]); 
        }
        else if(i==1){
            num_neighbours = stoi(myText);
        }
        else if(i==2){
            for(int x=0; x<num_neighbours; x++){
                neighbour_id[x]=stoi(list[x*2]);
                neighbour_port[x]=stoi(list[x*2 + 1]);
            }
        }
        else if(i==3){
            num_files = stoi(myText);
        }
        else {

            if(i-4 == num_files-1) file_names[i-4] = myText;
            
            else{int text_len = myText.length();
            
            file_names[i-4]="";
            for (int a=0; a<text_len-1; a++){
                file_names[i-4]= file_names[i-4] + myText[a];
            }}
        }
        i++;
    }

    MyReadFile.close();


    int status,our_socket;
    struct addrinfo hints, *p;
    struct addrinfo *res;  // will point to the results
    fd_set master;    // master file descriptor list
    fd_set read_fds;  // temp file descriptor list for select()
    int fdmax;
    char remoteIP[INET6_ADDRSTRLEN];
    struct sockaddr_storage their_addr;
    socklen_t addr_size;
    int new_socket;
    int new_client_socket;
    int yes=1;

    FD_ZERO(&master);    // clear the master and temp sets
    FD_ZERO(&read_fds);

    memset(&hints, 0, sizeof hints); // make sure the struct is empty
    hints.ai_family = AF_UNSPEC;     // don't care IPv4 or IPv6
    hints.ai_socktype = SOCK_STREAM; // TCP stream sockets
    hints.ai_flags = AI_PASSIVE;     // fill in my IP for me

    string clientport = std::to_string(client_port);
    if ((status = getaddrinfo(NULL, const_cast<char*>(clientport.c_str()), &hints, &res)) != 0) {
        fprintf(stderr, "getaddrinfo error: %s\n", gai_strerror(status));
        //exit(1);
    }

    for(p = res; p != NULL; p = p->ai_next) {
        our_socket = socket(p->ai_family, p->ai_socktype, p->ai_protocol);
        if (our_socket < 0) { 
            continue;
        }
        
        // lose the pesky "address already in use" error message
        setsockopt(our_socket, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int));

        if (bind(our_socket, p->ai_addr, p->ai_addrlen) < 0) {
            close(our_socket);
            continue;
        }

        break;
    }

    if (p == NULL) {
        fprintf(stderr, "selectserver: failed to bind\n");
        exit(2);
    }

    freeaddrinfo(res); // all done with this

    if(int lis = listen(our_socket, 10)<0){
        perror("listen");
        exit(3);
    }

    FD_SET(our_socket, &master);

    // keep track of the biggest file descriptor
    fdmax = our_socket; // so far, it's this one


    int status1,client_socket;
    struct addrinfo hints1;
    struct addrinfo *res1,*p1;  // will point to the results
    string neighbourport;

     
    for(int i=0; i<num_neighbours; i++){
        memset(&hints1, 0, sizeof hints1); // make sure the struct is empty
        hints1.ai_family = AF_UNSPEC;     // don't care IPv4 or IPv6
        hints1.ai_socktype = SOCK_STREAM; // TCP stream sockets
        hints1.ai_flags = AI_PASSIVE;     // fill in my IP for me

        neighbourport = std::to_string(neighbour_port[i]);
        if ((status1 = getaddrinfo(NULL, const_cast<char*>(neighbourport.c_str()), &hints1, &res1)) != 0) {
            fprintf(stderr, "getaddrinfo error: %s\n", gai_strerror(status1));
            //exit(1);
        }

        for(p1 = res1; p1 != NULL; p1 = p1->ai_next) {
            client_socket = socket(p1->ai_family, p1->ai_socktype, p1->ai_protocol);
            if (client_socket < 0) { 
                continue;
            }
            
            // lose the pesky "address already in use" error message
            setsockopt(client_socket, SOL_SOCKET, SO_REUSEADDR, &yes, sizeof(int));

            if (connect(client_socket, p1->ai_addr, p1->ai_addrlen) < 0) {
                close(client_socket);
                continue;
            }

            FD_SET(client_socket,&master);
            if(client_socket>fdmax){
                fdmax = client_socket;
            }

            int lenn, bytes_sentt;
            string msg;

            msg = to_string(unique_private_id) + "," +to_string(x);
            for (int i=0; i<x;i++){
                msg = msg + ","+ my_files[i] ;
            }
            lenn = msg.length();
            bytes_sentt = send(client_socket, msg.c_str(), lenn, 0);
    
            if(bytes_sentt == -1){
                perror("send");
            } 

            break;
        }

        freeaddrinfo(res1);
    }

    int n=0;
    string recieved_files[num_neighbours][1000],unique_ids[num_neighbours],no_files[num_neighbours];

    for(;;){
        read_fds = master; // copy it
        if (select(fdmax+1, &read_fds, NULL, NULL, NULL) == -1) {
            perror("select");
            //exit(4);
        }

        for(i = 0; i <= fdmax; i++){ //looping through existing connections
            if (FD_ISSET(i, &read_fds)){
                if(i == our_socket){ //accepting new connections


                    addr_size = sizeof their_addr;
                    new_socket = accept(our_socket, (struct sockaddr *)&their_addr, &addr_size);

                    if(new_socket == -1){
                        perror("accept");
                    }
                    else{
                        FD_SET(new_socket,&master);
                        if(new_socket>fdmax){
                            fdmax = new_socket;
                        }

                        int len, bytes_sent;
                        string msgg;
                        char* id = const_cast<char*>(std::to_string(unique_private_id).c_str());
                       
                        msgg = to_string(unique_private_id) + "," +to_string(x);
                        for (int i=0; i<x;i++){
                            msgg = msgg + "," + my_files[i];
                        }
                        len = msgg.length();
                        bytes_sent = send(new_socket, msgg.c_str(), len, 0);

                        if(bytes_sent == -1){
                            perror("send");
                        } 

                    }

                }
                else{ //handling data from client
                    char buf[256];
                    int bytes;
                    if ((bytes = recv(i, buf, sizeof buf, 0)) <= 0) {
                        // got error or connection closed by client
                        if (bytes == 0) {
                            // connection closed
                        } else {
                            perror("recv");
                        }
                        FD_CLR(i, &master); // remove from master set

                    }
                    else{
                        string out(buf,buf+bytes);
                        
                        int out_len = out.length();
                        char outchar[out_len+1];
                        strcpy(outchar, out.c_str());
     
                        // Returns first token
                        char *token = strtok(outchar, ",");

                        int y=0;
                        while(token != NULL){
                            if(y==0){
                                unique_ids[n] = token;
                            }
                            else if(y == 1){
                                no_files[n] = token;
                            }
                            else{
                                recieved_files[n][y-2] = token;
                            }
                            y++;
                            token = strtok(NULL, ",");
                        }

                        n++;
                        if(n==num_neighbours) { goto finall;}

                    }
                }
            }
        }
    }
    finall: 

    string outt[num_files];
    for(int a=0; a<num_files; a++){
        bool found = false;
        int unique_id_min[1000];
        int unique_id;
        int y=0;
        for(int i=0;i<n;i++){
            for (int j=0; j<stoi(no_files[i]);j++){ 
                if(recieved_files[i][j].compare(file_names[a])==0){
                    unique_id_min[y] = stoi(unique_ids[i]);
                    y++;
                    found = true;
                    
                }
            }
            
        }
        if(!found){
            outt[a] = "Found " + file_names[a] + " at 0 with MD5 0 at depth 0";
        }
        else{
            unique_id = unique_id_min[0];
            for(int r=1;r<y;r++){
                if(unique_id_min[r]<unique_id){
                    unique_id = unique_id_min[r];
                }
            }
            outt[a] = "Found " + file_names[a] + " at " + to_string(unique_id) + " with MD5 0 at depth 1";
        }
    }
    sort_name(outt, num_files-1);
    for(int i=0;i<num_files;i++){
        cout << outt[i] << endl;
    }
}  

/*
For testing:
g++ -std=c++17 client-phase2.cpp -o ./client-phase2
./client-phase2 clientx-config.txt "./files/clientx"        (x = client number)
*/