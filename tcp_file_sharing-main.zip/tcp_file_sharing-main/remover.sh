#!/usr/bin/env bash

[[ -d files/client1/Downloaded/ ]] && rm -rf files/client1/Downloaded/
[[ -d files/client2/Downloaded/ ]] && rm -rf files/client2/Downloaded/
[[ -d files/client3/Downloaded/ ]] && rm -rf files/client3/Downloaded/
[[ -d files/client4/Downloaded/ ]] && rm -rf files/client4/Downloaded/
[[ -d files/client5/Downloaded/ ]] && rm -rf files/client5/Downloaded/
